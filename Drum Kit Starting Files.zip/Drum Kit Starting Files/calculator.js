function add(m1,m2){
    return m1+m2;
}

function sub(m1,m2){
    return m1-m2;
}

function multiply(m1,m2){
    return m1*m2;
}

function devide(m1,m2){
    return m1/m2;
}

function calculator(m1,m2,ope){
    return ope(m1,m2);
}
